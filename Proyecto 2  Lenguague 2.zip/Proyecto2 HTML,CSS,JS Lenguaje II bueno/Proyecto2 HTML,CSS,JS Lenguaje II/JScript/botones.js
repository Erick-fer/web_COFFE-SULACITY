function viewPage(pageName) {
    const pageUrl = `erickF.html/${pageName}`;
    window.location.href = pageUrl; 
}

