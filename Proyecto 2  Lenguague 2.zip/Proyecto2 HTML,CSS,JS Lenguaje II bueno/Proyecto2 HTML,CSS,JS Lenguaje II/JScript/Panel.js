function validar(){
    let nombre, user, password, password2, correo, telefono, fecha,file, textArea;
    nombre = document.getElementById("nombre").value;
    user = document.getElementById("usuario").value;
    password = document.getElementById("contraseña").value;
    password2 = document.getElementById("contraseña2").value;
    correo = document.getElementById("correo").value;
    telefono = document.getElementById("telefono").value;
    fecha = document.getElementById("birthday").value;
    file = document.getElementById("myfile").value;
    textArea = document.getElementById("textarea").value;

    let validPass = false;
    if (password2 == password){
        validPass = true;
    }
    let valid = false;
    if(document.getElementById("masculino").checked){
        valid = true;
    }
    if(document.getElementById("femenino").checked){
        valid = true;
    }


    if(user == "" || password == "" || nombre == "" || password2 == "" || validPass == false || correo == "" || telefono == "" || fecha == "" || textArea == "" || file == "" || valid == false){
        if (nombre == "") {
            document.getElementById("comentario").innerHTML = "El campo nombre no puede estar vacío";
        }
        if (user == "") {
            document.getElementById("comentario").innerHTML = "El usuario no debe estar vacío";
        }
        if (password == "") {
            document.getElementById("comentario").innerHTML = "La contraseña está vacía";
        }
        if (password2 == "") {
            document.getElementById("comentario").innerHTML = "Confirma la contraseña";
        }
        if (validPass == false) {
            document.getElementById("comentario").innerHTML = "Las contraseñas no coinciden";
        }
        if (correo == "") {
            document.getElementById("comentario").innerHTML = "El campo correo no puede estar vacío";
        }
        if (telefono == "") {
            document.getElementById("comentario").innerHTML = "El campo telefono no puede estar vacío";
        }
        if (valid == false){
            document.getElementById("comentario").innerHTML = "Selecciona el sexo";
        }
        if (fecha == "") {
            document.getElementById("comentario").innerHTML = "Selecciona la feha de nacimiento";
        }
        if (file == "") {
            document.getElementById("comentario").innerHTML = "Selecciona una fotografía";
        }
        if (textArea == false) {
            document.getElementById("comentario").innerHTML = "Agrega una descripción";
        }
    }
    else{
        alert("Usuario agregado con éxito");
        document.getElementById("comentario").innerHTML = "Usuario agregado con éxito";
    }   
}