function iniciarS(){
    let user, password;
    user = document.getElementById("usuario").value;
    password = document.getElementById("contraseña").value;
    
    const validUsername = 'admin';
    const validPassword = 'admin31';

    
    if (user === validUsername && password === validPassword) {
        alert('Inicio de sesión exitoso!');
    } else {
        document.getElementById('error-message').textContent = 'Usuario o clave incorrectos.';
    }

    if(user == "" || password == ""){
        console.log("El usuario y/o la contraseña no pueden estar vacios");
        if (password == "") {
            document.getElementById("comentario").innerHTML = "El campo la contraseña está vacía"
        }
        if (user == "") {
            document.getElementById("comentario").innerHTML = "El campo del usuario está vacío"
        }
    }
    else{
        window.location="Panel de usuario.html";
    }   
}


function mostrarpassword(){
    const icon = document.querySelector("i");
    let tipo = document.getElementById("contraseña");
    if(tipo.type == "password"){
        tipo.type = "text";
        icon.classList.remove("fa-eye-slash");
        icon.classList.add("fa-eye");
    }else{
        tipo.type = "password";
        icon.classList.remove("fa-eye");
        icon.classList.add("fa-eye-slash")
    }   
}