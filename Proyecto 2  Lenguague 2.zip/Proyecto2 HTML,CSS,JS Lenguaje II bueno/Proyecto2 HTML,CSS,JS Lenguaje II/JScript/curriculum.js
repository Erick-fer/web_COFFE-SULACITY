function showBio(memberId) {
    const bio = document.getElementById(`bio-${memberId}`);
    
    if (bio) {
        const currentDisplay = window.getComputedStyle(bio).display;
        
        if (currentDisplay === "block") {
            bio.style.display = "none";
        } else {
            bio.style.display = "block";
        }
    } else {
        console.error(`No se encontró el elemento con ID: bio-${memberId}`);
    }
}
